
    <?php include '../top_page-post.php' ?>

    <div class = "title-post">
        <p><h1 class="txt-post-title"style="color:#8bc53f"> Hướng dẫn sử dụng chức năng quản lý thành viên Page</h1></p>
    </div>
    <div class = "adate">
        <p class="txt-adate"> Cập nhật: 22/07/2018 09:31:33 PM </p>
    </div>
    <div class = "">
        <p><strong>Hệ thống 24h NET trân trọng cảm ơn quý khách hàng đã quan tâm đến dịch vụ của chúng tôi!</strong></p>
    </div>
    <h3>B1: Tại thanh <strong>Menu</strong> các bạn chọn <strong>Quản lý thành viên</strong></h3>
    <div>
    <img src="/images/qltv2.png" alt="Quản lý thành viên" style = "max-width: 100%;height: auto;"   >
    </div>
    <hr>
    <p>Ở đây bạn sẽ chọn "Danh sách thành viên "</p>
    <p>1.2 - Sau khi chọn 'Danh sách thành viên ' sẽ hiện ra 1 cột chọn các Page bạn đang làm .
    <hr>
    <div>
    <img class = "img-hdsd" src="/images/qltv1.png" alt="Quản lý thành viên" style = "max-width: 100%;height: auto;"  >
    </div>
    <hr>
    <p>- Lưu ý : Các bạn cần có Page, các Page trên hệ thống có là các Page mà Boss đăng ký sử dụng tại hệ thống và không có là do Boss Page chưa đăng ký sử dụng nên hệ thống không có dữ liệu</p>
    <p>1.3 - Sau đó bạn chọn Page cần xem và nhấp "Xác nhận - xem " để xem thành viên.
    <p>- Khi đó giao diện xuất hiện như hình bên dưới :
    <hr>
    <div>
    <img src="/images/qltv.png" alt="Quản lý thành viên" style = "max-width: 100%;height: auto;" >
    <hr>
    </div>
    <p><strong>B2:</strong> Bạn muốn chuyển tiền, cấp tiền , trả thưởng cho Admin số tiền bao nhiêu hãy chọn nút <a style="color:red;"> " Cấp tiền "</a></p>
    <p>2.1 - Sau khi chọn nút cấp tiền cột <a style="color:red;">" Cấp tiền (VNĐ) "</a> sẽ được mở khóa và bạn có thể nhập số tiền cho từng thành viên bạn muốn trả thưởng.</p>
    <hr>
    <div>
    <img src="/images/qltv4.png" alt="Quản lý thành viên" style = "max-width: 100%;height: auto;" >
    </div>
    <hr>
    <p>2.2 - Bạn nhập số tiền VNĐ muốn chi trả cho admin của mình.</p>
    <p><strong>- Lưu ý :</strong> Tiền trong tài khoản của bạn phải đủ tổng tất cả số tiền đó cộng lại nhiều hơn hoặc bằng. Nếu không đủ hệ thống sẽ báo lỗi.</p>
    <p>2.3 - Đồng nghĩa sau khi bạn nhấp vào nút <a style="color:red;"> " Cấp tiền "</a>, bạn nhập số tiền xong nút <a style="color:green;"> " Cấp tiền xong "</a>sẽ có màu xanh lá, là đã mở khóa.</p>
    <hr>
    <img src="/images/qltv5.png" alt="Quản lý thành viên"  >
    <hr>
    <p>Bạn nhập số tiền xong và chọn <a style="color:green;"> " Cấp tiền xong "</a> thế là số tiền trong tài khoản của bạn sẽ được chuyển cho thành viên của bạn sau 1 giây.</p>
    <hr>
    <p><strong>B3:</strong> Ngoài ra bạn có thể chỉnh sửa tên , biệt hiệu(cre) cho từng admin trong Page của bạn. </p>
    <p>- Hãy nhấp nút <a style="color:green;">' Chỉnh sửa '</a> sau khi chỉnh sửa xong chọn <a style="color:green;">" Cập nhật " </a> để lưu lại nhé. Xin cảm ơn !</p>
    <hr>
    <p><strong>Mọi thắc mắc và đề nghị hợp tác, quý khách hàng vui lòng liên hệ:</strong></p>
    <p>
      - Email: <p style="color:MediumSeaGreen;">+) Admin@hethong24h.net</p>
      - Hotline: <p style="color:MediumSeaGreen;">+) 01658.654.111</p>

    </p>


    <?php include '../bottom_page-post.php' ?>
