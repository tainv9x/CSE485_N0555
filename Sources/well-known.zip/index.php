<!-- 1 -->
<?php include 'top_page2.php' ?>
<?php 
     $_SESSION['cuUrl'] = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
?>
                <!-- Today -->
                <div class="scroll-left">
                    <p><i class="fas fa-volume-up fa-1x"></i>Hệ Thống 24h NET là 1 tiện ích giúp Boss trả thưởng ,quản lý thành viên của Page một cách chuyên nghiệp dễ dàng và bớt tốn kém thời gian,hãy nhanh tay đăng ký để sử dụng ngay hôm nay ! </p>
                </div>
                <div style = " margin: 0 -15px;" class = "banner">
                  <img style = "max-width: 100%;height: auto;" src = "/images/banner.png" />

                </div>
                 <div class = "top_news" style = "background: #fff;">
                  <div class = "form-group">
                    <h5 class = "title-topnews">Tin tức mới</h5>
                    <div class="content-topnews">
                      <div class="row">
                        <div class = "col-md-3 col-sm-6">
                          <div class = "item-news">
                            <a href = "#" title = "Viettel tặng ngay 20% giá trị thẻ nạp vào ngày 20/7/2018">
                              <img src = "/images/viettelkm-20-7-2018.jpg">
                            </a>
                            <h4><a href = "#" title = "Viettel tặng ngay 20% giá trị thẻ nạp vào ngày 20/7/2018">Viettel tặng ngay 20% giá trị thẻ nạp vào ngày 20/7/2018</a></h4>
                          </div>
                        </div>
                        <div class = "col-md-3 col-sm-6">
                            <div class = "item-news">
                                <a href = "#" title = "MobiFone khuyến mãi 20% thẻ nạp TOÀN QUỐC vào ngày 18/7/2018">
                                  <img src = "/images/mobikm.jpg">
                                </a>
                                <h4><a href = "#" title = "MobiFone khuyến mãi 20% thẻ nạp TOÀN QUỐC vào ngày 18/7/2018">MobiFone khuyến mãi 20% thẻ nạp TOÀN QUỐC vào ngày 18/7/2018</a></h4>
                              </div>
                        </div>
                        <div class = "col-md-3 col-sm-6">
                            <div class = "item-news">
                                <a href = "#" title = "Khuyến mãi VinaPhone ngày 17/7/2018: Ưu đãi đến 20% thẻ nạp">
                                  <img src = "/images/vinakm.jpg">
                                </a>
                                <h4><a href = "#" title = "Khuyến mãi VinaPhone ngày 17/7/2018: Ưu đãi đến 20% thẻ nạp">Khuyến mãi VinaPhone ngày 17/7/2018: Ưu đãi đến 20% thẻ nạp</a></h4>
                              </div>
                        </div>
                        <div class = "col-md-3 col-sm-6">
                            <div class = "item-news">
                                <a href = "#" title = "Đừng bỏ lỡ: Khuyến mãi nạp thẻ MobiFone tặng 2GB đến 20GB vào ngày 12/7/2018">
                                  <img src = "/images/mobikm2.jpg">
                                </a>
                                <h4><a href = "#" title = "Đừng bỏ lỡ: Khuyến mãi nạp thẻ MobiFone tặng 2GB đến 20GB vào ngày 12/7/2018">Đừng bỏ lỡ: Khuyến mãi nạp thẻ MobiFone tặng 2GB đến 20GB vào ngày 12/7/2018</a></h4>
                              </div>
                        </div>

                      </div>
                    </div>
                  </div>

                </div>
                 <!-- end news -->
                <!-- product intro -->
                <section class = "product_intro">
                    <div class = "row">
                      <div class = "col-md-6">
                        <div class = "product_intro_text">
                          <div class = "content-left-intro">
                              <div class = "row">
                                <div class = "col-md-2 col-sm-3 col-xs-3">
                                  <img src = "/images/qlydongian.png" alt = "Quản lý thành viên hoàn hảo">
                                </div>
                                <div class = "col-md-10 col-sm-9 col-xs-9">
                                  <span class = "title-left-intro">Quản lý thành viên hoàn hảo, đơn giản</span>
                                  <p class = "txt-ano"></p>
                                  <p>Bạn chỉ việc nhấp chuột là có thể xem được tất cả thành viên của Page, Cộng tiền thưởng,lương chỉ bằng một cú nhấp chuột, quá tuyệt vời và không cần mất thời gian !</p>
                                </div>
                              </div>
                          </div>

                          <div class = "content-left-intro">
                              <div class = "row">
                                  <div class = "col-md-2 col-sm-3 col-xs-3">
                                    <img src = "/images/nhanh.png" alt = "Nhanh và dễ dàng">
                                  </div>
                                  <div class = "col-md-10 col-sm-9 col-xs-9">
                                    <span class = "title-left-intro">Nhanh và dễ dàng</span>
                                    <p class = "txt-ano"></p>
                                    <p>Với hệ thống ổn định, thao tác nạp tiền đơn giản và cơ chế cá nhân hóa nội dung dành riêng cho bạn, việc nạp tiền và thanh toán của bạn sẽ được thực hiện nhanh nhất có thể.</p>
                                  </div>
                                </div>
                          </div>

                          <div class = "content-left-intro">
                              <div class = "row">
                                  <div class = "col-md-2 col-sm-3 col-xs-3">
                                    <img src = "/images/baomat.png" alt = "Bảo mật tuyệt đối">
                                  </div>
                                  <div class = "col-md-10 col-sm-9 col-xs-9">
                                    <span class = "title-left-intro">Bảo mật tuyệt đối</span>
                                    <p class = "txt-ano"></p>
                                    <p>Tại HeThong24h, mọi thông tin của bạn sẽ được bảo mật tuyệt đối để bạn an tâm nạp tiền bất cứ nơi đâu, bất cứ khi nào!</p>
                                  </div>
                                </div>
                          </div>

                          <div class = "content-left-intro">
                              <div class = "row">
                                  <div class = "col-md-2 col-sm-3 col-xs-3">
                                    <img src = "/images/hotro247.png" alt = "Hỗ trợ 24/7">
                                  </div>
                                  <div class = "col-md-10 col-sm-9 col-xs-9">
                                    <span class = "title-left-intro">Hỗ trợ 24/7</span>
                                    <p class = "txt-ano"></p>
                                    <p>Đội ngũ HeThong24h luôn sẵn sàng hỗ trợ bạn trong mọi tình huống, bất kể ngày đêm một cách nhanh nhất qua tất cả các kênh.</p>
                                  </div>
                                </div>
                          </div>

                        </div>

                      </div>
                      <div class = "col-md-6 hidden-xs">
                        <div class = "img-product-intro">
                          <img src = "/images/phone-cover-1.png">
                        </div>
                      </div>
                    </div>
                </section>
                <!-- end product intro -->
                <?php include 'bottom_page1.php' ?>
<!--<div id='notify'>-->
<!--<div class='notify'>-->
<!--  <h3> THÔNG BÁO </h3>-->
<!--  <p><b>+)</b> Bắt buộc cài mật khẩu cấp 2, Các bạn vào mục <a href="https://hethong24h.net/quenmk2.php" ><b>Tài khoản > (Đổi & Lấy) lại mật khẩu cấp 2</b></a> để cập nhật lại MKC2 nhé !-->
<!--      <br><b>+)</b> Các bạn vui lòng vào <a href="https://hethong24h.net/info.php" ><b>Tài khoản > Thông tin tài khoản</b></a> Chỉnh sửa > Cập nhật lại Page mình đang làm nhé !-->
<!--    <br><b>+)</b> Cập nhật Page xong sẽ phải chờ Boss Page phê duyệt nhé !-->
<!--    <center><a class='ok-button' onclick='document.getElementById(&#39;notify&#39;).style.display = &#39;none&#39;'>Đóng</a></center>-->
<!--  </div>-->
<!--</div>-->
<!DOCTYPE html>
<!--<html lang="en">-->
<!--<head>-->
<!--  <title>Bootstrap Example</title>-->
<!--  <meta charset="utf-8">-->
  <!--<meta name="viewport" content="width=device-width, initial-scale=1">-->
  <!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">-->
  <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>-->
  <!--<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>-->
    <script src="//bootstrap.min.js"></script>
<!--</head>-->
<!--<body>-->

<div class="container">
  <!--<h2>Activate Modal with JavaScript</h2>-->
  <!-- Trigger the modal with a button -->
  <!--<button type="button" class="btn btn-info btn-lg" id="myBtn">Open Modal</button>-->

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h2 class="modal-title" style="text-align:center">THÔNG BÁO</h2>
        </div>
        <div class="modal-body">
          <!--<p><c>+</c> <d>BẮT BUỘC</d> cài MKC2, để cài <d>MKC2</d> làm như sau : -->
          <!--<br><d>-</d> Trên thanh <c>Menu</c> chọn <a href=""><c>Tài khoản</c></a> ☞ <a href="https://hethong24h.net/quenmk2.php" ><l>Lấy lại mật khẩu cấp 2</l></a>-->
          <c>+</c> Hệ thống <e>TĂNG</e> <d>LIKE, Comment, View, Follow, Livestream</d> <a href="https://likebank.vn" target=_blank>☞ <l>Likebank.vn</l></a>
          <br><c>+</c> Tuyển CTV <e>có vốn trên 1.000.000đ</e> thu nhập đảm bảo <d>từ 5.000.000đ - 10.000.000đ</d> 1 tháng <a href="https://likebank.vn/register" target=_blank>☞ <l>tại đây!</l></a>
          <br><c>+</c> Các bạn nào có nhu cầu làm <e>CTV</e> của <d>Likebank.vn</d> hãy inbox qua Facebook - <a href="https://facebook.com/taikute" target=_blank><e>Tài Nguyễn</e></a>
    <!--<br><c>+</c> Các bạn mua thẻ <e>điện thoại</e> <d>VIETTEL, VINA, MOBI, VNMOBILE</d> <a href="https://hethong24h.net/muathe.php">☞ <l>tại đây!</l></a>-->
    <!--<br><c>+</c> Thẻ <e>GAME</e> có thể mua <d>Garena, Zing, Gate, VCoin</d> <a href="https://hethong24h.net/thegame.php">☞ <l>tại đây!</l></a>-->
    <br><c>+</c> Tham gia <f>" GROUP FACEBOOK "</f> để hỗ trợ,hỏi đáp <a href="https://www.facebook.com/groups/hethong24h.net" target=_blank>☞ <el>tại đây!</el></a>
    <!--<br><c>+</c> Các bạn theo dõi <f>Channel Telegram</f> của <e>24H NET</e> để cập nhật các thông tin mới nhất <a href="http://t.me/hethong24h" target=_blank>☞ <el>tại đây!</el></a>-->
    <br><c>+</c> <d>BOSS</d> nào muốn sử dụng hệ thống quản lý thành viên, hãy <d>đăng ký</d> <a href="https://hethong24h.net/dkdv.php">☞ <l>tại đây!</l></a>
    <!--<br><c>+</c> Các bạn vào mục <a href="https://hethong24h.net/info.php" ><c>Tài khoản ></c><l> Thông tin tài khoản</l></a> để cập nhật lại <d>PAGE</d> mình đang làm.-->
        </div>
        <!--<div class="modal-footer">-->
        <!--  <button type="button" class="btn btn-default" data-dismiss="modal">Đóng</button>-->
        <!--</div>-->
      </div>
      
    </div>
  </div>
  
</div>
<script>

$(document).ready(function(){
   
        $("#myModal").modal();

});
</script>

<!--</body>-->
<!--</html>-->

