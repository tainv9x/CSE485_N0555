<?php include 'top_page.php' ?>
    <a href = "ls_chuyen_tien.php">Lịch sử chuyển tiền</a><br>
    <a href = "ls_nhan_tien.php">Lịch sử nhận tiền</a><br>
    <a href = "ls_mua_the.php">Lịch sử mua thẻ</a><br>
    <a href = "ls_nap_sdt.php">Lịch sử nạp tiền điện thoại</a>




<?php include 'bottom_page.php' ?>