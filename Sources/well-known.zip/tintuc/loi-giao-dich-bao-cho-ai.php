<?php include '../top_page-post.php' ?>

<div class = "title-post">
    <p><h1 class="txt-post-title"style="color:#8bc53f"> Lỗi giao dịch thì phải làm thế nào ? Báo cho ai ?</h1></p>
</div>
<div class = "adate">
    <p class="txt-adate"> Cập nhật: 22/07/2018 09:31:33 PM </p>
</div>
<div class = "">
    <p><strong>Hệ thống 24h NET trân trọng cảm ơn quý khách hàng đã quan tâm đến dịch vụ của chúng tôi!</strong>
</div>
<p></strong>Kiểm tra lại các thông tin bạn đã nhập, thực hiện lại giao dịch trong tab mới.</strong>

<p>Nếu bạn vẫn gặp vấn đề trong một số giao dịch, hãy liên lạc ngay với chúng tôi qua:

<p><a style="color:red ">- Hotline:</a> 01658.654.111
<p><a style="color:red ">- Email:</a> Admin@HeThong24h.NET
<p><a style="color:red ">- ChatLive</a> trực tiếp trên website
<p><a style="color:red ">- Fanpage:</a> để lại tin nhắn trên fanpage
<hr>
<p>
    <div>
        <img src="/images/loigd.png" alt="Lỗi giao dịch hethong24h.net"  style="max-width:100%; width:auto;display: block; margin-left: auto; margin-right: auto; " >
    </div>
</p>
<hr>
<p>- Đăng ký tài khoản, mua thẻ cào online ngay tại HeThong24h.NET để nhận ưu đãi lớn nhất.
<p><strong>Mọi thắc mắc và đề nghị hợp tác, quý khách hàng vui lòng liên hệ:</strong></p>
    <p>
      - Email: <p style="color:MediumSeaGreen;">+) Admin@hethong24h.net</p>
      - Hotline: <p style="color:MediumSeaGreen;">+) 01658.654.111</p>

    </p>


    <?php include '../bottom_page-post.php' ?>
