
    <?php include '../top_page-post.php' ?>

    <div class = "title-post">
        <p><h1 class="txt-post-title"style="color:#8bc53f"> Hướng dẫn đăng ký sử dụng chức năng QLTV của Page mình.</h1></p>
    </div>
    <div class = "adate">
        <p class="txt-adate"> Cập nhật: 22/07/2018 09:31:33 PM </p>
    </div>
    <div class = "">
        <p><strong>Hệ thống 24h NET trân trọng cảm ơn quý khách hàng đã quan tâm đến dịch vụ của chúng tôi!</strong>
    </div>
    <h3>B1: Tại thanh <strong>Menu</strong> các bạn chọn <strong>Quản lý thành viên</strong></h3>
    <p>
      <strong>B2:</strong> chọn <a style="color:red">Đăng ký sử dụng</a>
    </p>
    <p>
      - Khi nhấp vào giao diện sẽ có như hình dưới
    </p>
    <div>
      <img src="/images/dksd.png" alt="Đăng ký Page với hệ thống" style="max-width:100% ;width:auto;" >
    </div>
    <p>
      + Tiếp theo các bạn nhập thông tin Page của các bạn như ví dụ bên trên.
    </p>
    <P>
      <strong>Chọn gói</strong> và nhấp vào nút <a style="color:#337ab7 ">Thực hiện</a>
    </P>
    <p>
      <strong>B3:</strong> bạn sẽ chờ hệ thống phê duyệt và update tên Page của bạn sau khoảng 1 chút thời gian.
    </p>
    <p><strong>Mọi thắc mắc và đề nghị hợp tác, quý khách hàng vui lòng liên hệ:</strong></p>
    <p>
      - Email: <p style="color:MediumSeaGreen;">+) Admin@hethong24h.net</p>
      - Hotline: <p style="color:MediumSeaGreen;">+) 01658.654.111</p>

    </p>


    <?php include '../bottom_page-post.php' ?>
