
    <?php include '../top_page-post.php' ?>

    <div class = "title-post">
        <p><h1 class="txt-post-title"style="color:#8bc53f"> Hướng dẫn phê duyệt yêu cầu tham gia thành viên Page của bạn.</h1></p>
    </div>
    <div class = "adate">
        <p class="txt-adate"> Cập nhật: 22/07/2018 09:31:33 PM </p>
    </div>
    <div class = "">
        <p><strong>Hệ thống 24h NET trân trọng cảm ơn quý khách hàng đã quan tâm đến dịch vụ của chúng tôi!</strong>
    </div>
    <h3>B1: Tại thanh <strong>Menu</strong> các bạn chọn <strong>Quản lý thành viên</strong></h3>
    <p>
      <strong>B2:</strong> chọn <a style="color:red">Yêu cầu chờ phê duyệt (Quản lý)</a>
      <p>
        - Lưu ý : Chỉ Boss có cấp độ Lv2 trong Page mới có thể sử dụng chức năng này !
      </p>
    </p>
    <p>
      - Khi nhấp vào giao diện sẽ có như hình dưới
    </p>
    <div>
      <img src="/images/pheduyet.png" alt="Yêu cầu chờ phê duyệt (Quản lý)" style="max-width:100%; width:auto;" />
    </div>
    <p>
      + Tiếp theo các bạn chọn <strong>Page</strong> của mình đang <strong>Quản lý</strong> và nhấn <a style="color:#8bc53f">Xác nhận - Xem</a>
    </p>
    <p>
      <strong>B2:</strong>Sau khi nhấn Xem thì giao diện demo như hình dưới.
    </P>
    <div>
      <img src="/images/pheduyet1.png" alt=" Yêu cầu phê duyệt thành viên" style="max-width:100%;width:auto;" />
    </div>
    <p>
      <strong>B3:</strong> bạn CHẤP NHẬN thì người đó mới được tham gia làm thành viên của Page bạn.
      <p>
        - Ngược lại nếu TỪ CHỐI thì sẽ không được tham gia.
      </p>
    </p>
    <p><strong>Mọi thắc mắc và đề nghị hợp tác, quý khách hàng vui lòng liên hệ:</strong></p>
    <p>
      - Email: <p style="color:MediumSeaGreen;">+) Admin@hethong24h.net</p>
      - Hotline: <p style="color:MediumSeaGreen;">+) 01658.654.111</p>

    </p>


    <?php include '../bottom_page-post.php' ?>
