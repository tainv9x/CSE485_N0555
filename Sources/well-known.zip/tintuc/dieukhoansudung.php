
    <?php include '../top_page-post.php' ?>

    <div class = "title-post">
        <p><h1 class="txt-post-title"style="color:#8bc53f"> Điều khoản sử dụng </h1></p>
    </div>
    <div class = "adate">
        <p class="txt-adate"> Cập nhật: 22/07/2018 09:31:33 PM </p>
    </div>
    <div class = "">
        <p><strong>Nội dung điều khoản </strong></p>
    <p>-Cam kết có hiệu lực từ tháng 07 năm 2018 , tất cả thành viên, cá nhân, tổ chức sử dụng dịch vụ tại <strong>HeThong24h NET</strong> bắt buộc phải đọc và cam kết nội dung này khi đăng ký và sử dụng dịch vụ của <strong>HeThong24h NET</strong>.
      <p>Cam kết này có giá trị pháp lý là một văn bản giao kết thương mại giữa <strong>HeThong24h NET</strong> và người sử dụng.
      <p>Tất cả thành viên sử dụng bất kỳ dịch vụ nào trên <strong>HeThong24h NET</strong> được hiểu là mặc định đã ký vào cam kết này và chịu trách nhiệm trước pháp luật nước CHXHCN Việt Nam .

    <p><strong>CĂN CỨ</strong></p>
    <p>- Việc đăng ký tài khoản và hoạt động kinh doanh trực tuyến cần đảm bảo đúng pháp luật nước CHXHCN Việt Nam.
    <p>Căn cứ : Luật giao dịch điện tử số 51/2005/QH11 do Quốc hội thông qua ngày 29/11/2005;Nghị định số 57/2006/NĐ-CP do Chính phủ ban hành ngày 09/06/2006 về thương mại điện tử;Thông tư số 09/2008/TT-BCT do Bộ công thương ban hành ngày 21/07/2008 hướng dẫn nghị định Thương mại điện tử về cung cấp thông tin và giao kết hợp đồng trên website thương mại điện tử.

    <p>- <strong>HeThong24h NET</strong> cho phép : đăng ký miễn phí tài khoản tại HeThong24h.Net khi người dùng cam kết cung cấp thông tin đúng quy định.

    <p>- <strong>HeThong24h NET</strong> cho phép mọi cá nhân có nhu cầu mua bán, trao đổi mọi loại hàng hóa, dịch vụ mà <strong>HeThong24h</strong> cung cấp; các tổ chức, cá nhân có nhu cầu tích hợp thanh toán (các phương thức tích hợp có sẵn của <strong>HeThong24h</strong>) có thể đăng ký miễn phí và sử dụng tự do mọi công cụ trên website

    <p>- Nhu cầu của người muốn sử dụng dịch vụ, hàng hóa do HeThong24h.Net cung cấp và tích hợp các công cụ thanh toán của <strong>HeThong24h NET</strong>
    .
    <p><strong>TÔI LÀ:</strong></p>
    <p>- Cá nhân đăng ký tài khoản <strong>HeThong24h NET</strong> để giao dịch trực tuyến vật phẩm ảo trong Game Online

    <p>- Cá nhân hoặc cá nhân đại diện cho tổ chức sử dụng <strong>HeThong24h NET</strong> cho việc tích hợp thanh toán trực tuyến cho hoạt động kinh doanh trực tuyến của cá nhân/tổ chức.

    <p><strong>TÔI XIN CAM KẾT ĐÃ HIỂU VÀ THỪA NHẬN NHỮNG ĐIỀU SAU:</strong></p>
    <p>- Webiste HeThong24h.Net là một website kinh doanh và cung cấp dịch vụ hỗ trợ giao dịch các sản phẩm có giá trị liên quan đến dịch vụ trò chơi trực tuyến Game Online và các giải pháp tích hợp thanh toán trực tuyến.

    <p>- Website HeThong24h.Net thuộc sở hữu của Công ty TNHH một thành viên HeThong24h.Net là một pháp nhân được thành lập và hoạt động hợp pháp theo pháp luật Việt Nam, có đẩy đủ năng lực cung cấp dịch vụ, sản phẩm trực tuyến.

    <p>- Khi tôi sử dụng giải pháp tích hợp thanh toán trực tuyến do HeThong24h.Net cung cấp, tôi thừa nhận rằng <strong>HeThong24h NET</strong> chỉ cung cấp giải pháp tích hợp thanh toán trung gian mà không có bất cứ liên quan nào về hoạt động kinh doanh, pháp lý với các sản phẩm hoặc/và dịch vụ mà tôi cung cấp cho khách hàng của mình.

    <p>- Khi phát hiện bất kỳ một giao dịch/khoản tiền nào của tôi có dấu hiệu nghi vấn, HeThong24h.Net có quyền từ chối cung cấp sản phẩm, dịch vụ cho tôi mà không cần báo trước hoặc/và xử lý các sai phạm đó bằng hình thức: Hạn chế một vài chức năng, đóng băng một khoản tiền, phong tỏa tài khoản, khóa truy cập tài khoản, ngừng cung cấp dịch vụ hoặc lập hồ sơ gửi cơ quan công an v.v… tùy theo mức độ cho đến khi làm sáng tỏ.

    <p><strong>TÔI XIN CAM KẾT CHỊU TRÁCH NHIỆM TRƯỚC PHÁP LUẬT NHỮNG ĐIỀU SAU :</strong></p>
    <p>- Tôi cam kết chịu trách nhiệm hoàn toàn trước pháp luật về các hoạt động kinh doanh, thương mại, sản phẩm, dịch vụ, giao dịch trực tuyến của mình khi sử dụng giải pháp tích hợp thanh toán của <strong>HeThong24h NET</strong>.

    <p>- Tôi cam kết toàn bộ hoạt động sử dụng dịch vụ, mua bán các sản phẩm, dịch vụ của <strong>HeThong24h NET</strong> được thực hiện theo đúng quy định pháp luật hiện hành nước Cộng hòa xã hội chủ nghĩa Việt Nam.

    <p>- Tôi cam kết toàn bộ thông tin đăng ký tài khoản và giao dịch trên <strong>HeThong24h NET</strong> là chính xác và tôi chịu trách nhiệm hoàn toàn tính xác thực thông tin mình cung cấp.

    <p>- Tôi cam kết phối hợp chặt chẽ với <strong>HeThong24h NET</strong> và cơ quan điều tra trong mọi trường hợp xác minh các dấu hiệu lừa đào, vi phạm pháp luật nước Cộng hòa xã hội chủ nghĩa Việt Nam

    <p>Với các cam kết trên Tôi đồng ý đăng ký sử dụng dịch vụ của <strong>HeThong24h NET</strong>.

    </p>

</div>
    <?php include '../bottom_page-post.php' ?>
