$(document).ready(function(){
  $('#btnShowFruit').click(function() {
    var fruit =$('#txtFruit').val();
    $('#showPic').html('<img src="images/'+fruit+'.jpeg" alt="Toi la"+fruit)
    $('#showPic').addClass('vienxanh');   
  })
})